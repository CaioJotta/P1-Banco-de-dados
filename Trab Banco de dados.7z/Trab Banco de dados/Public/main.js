function fazerLogin(username, password) {
    axios.post('http://localhost:3000/login', { username, password })
      .then(response => {
        if (response.status === 200) {
          // Se o login for bem-sucedido, você pode fazer o redirecionamento aqui no lado do cliente.
          window.location.href = 'http://localhost:5000/products'; // Redirecionamento para uma rota do Flask
        } else {
          console.error('Login falhou');
        }
      })
      .catch(error => {
        console.error('Erro ao fazer login:', error);
      });
  }
  
  // Exemplo de uso da função de login
  fazerLogin('nome_de_usuario', 'senha');