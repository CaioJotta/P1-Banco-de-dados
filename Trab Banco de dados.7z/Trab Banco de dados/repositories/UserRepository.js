class UserRepository {
    constructor(model) {
      this.model = model;
    }
  
    async create(data) {
      return this.model.create(data);
    }
  
    async findByUsername(username) {
      return this.model.findOne({ username });
    }
  }
  
  module.exports = UserRepository;