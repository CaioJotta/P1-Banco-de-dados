const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const User = require('./models/User');
const UserRepository = require('./repositories/UserRepository');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const path = require('path');

const app = express();
app.use(bodyParser.json());

const users = [
  { id: 1, username: 'Caio', password: '12345' } 
];

const JWT_SECRET = 'mysecret';

mongoose.connect('mongodb://localhost:27017/userDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const userRepository = new UserRepository(User);

app.use(express.static(path.join(__dirname, 'public')));

app.post('/register', async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const user = { username: req.body.username, password: hashedPassword };
    const newUser = await userRepository.create(user);
    res.status(201).send(newUser);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  app.post('/login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const user = await userRepository.findByUsername(username);
  
      if (!user) {
        return res.status(400).send('Usuário não encontrado');
      }
  
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        return res.status(401).send('Credenciais inválidas');
      }
  
      const token = jwt.sign({ username: user.username }, JWT_SECRET);
      return res.json({ token });
    } catch (error) {
      console.error('Erro durante login:', error); // Adiciona mais informações ao log de erro
      return res.status(500).send('Erro interno do servidor');
    }
  });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});